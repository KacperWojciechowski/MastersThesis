//#include <sharkModels.hpp>
#include <inc/shogun/shogunModels.hpp>

int main()
{
    //sharkModels();
    shogunModels();
}